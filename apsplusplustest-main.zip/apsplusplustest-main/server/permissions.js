module.exports = [
    {
        "key": process.env.TOKEN_1,
        "discordID": "0",
        "nameColor": "#ffffff",
        "class": "developer",
        "infiniteLevelUp": true,
        "name": "unnamed#0000",
        "note": "note here"
    },
    {
        "key": process.env.TOKEN_2,
        "discordID": "0",
        "nameColor": "#ffffff",
        "class": "developer",
        "infiniteLevelUp": true,
        "name": "unnamed#0000",
        "note": "note here"
    },
    {
        "key": process.env.TOKEN_3,
        "discordID": "0",
        "nameColor": "#ffffff",
        "class": "developer",
        "infiniteLevelUp": true,
        "name": "unnamed#0000",
        "note": "note here"
    },
    {
        "key": process.env.TOKEN_4,
        "discordID": "0",
        "nameColor": "#ffffff",
        "class": "developer",
        "infiniteLevelUp": true,
        "name": "unnamed#0000",
        "note": "note here"
    },
]
