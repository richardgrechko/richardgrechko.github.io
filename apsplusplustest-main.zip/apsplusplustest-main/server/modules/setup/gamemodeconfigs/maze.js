module.exports = {
    MAZE: 30,
    ROOM_SETUP: ['overlay_maze'],
};